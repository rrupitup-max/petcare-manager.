# PetCare Manager

A responsive starter application for a pet shop with grooming services.

## Features
- Dashboard with daily sales, appointments, product count and customer count
- Product inventory with selling price, cost, stock and low-stock thresholds
- Grooming appointment creation, editing and status updates
- Sales recording that automatically deducts inventory stock
- Customer and pet profiles
- CSV exports for sales and grooming reports
- Responsive layout for desktop and mobile
- Demo data saved in the browser using localStorage

## Run locally

Install Node.js (LTS), then open a terminal in this folder:

```bash
npm install
npm run dev
```

Open the local URL Vite prints, usually http://localhost:5173.

To create a production build:

```bash
npm run build
```

## Publish with GitHub + Cloudflare Pages

1. Create a GitHub account and a new repository named `petcare-manager`.
2. Upload the contents of this folder to the repository (the `src` folder, `index.html`, `package.json`, etc.).
3. In Cloudflare, open Workers & Pages and create a Pages project connected to your GitHub repository.
4. Framework preset: **Vite**.
5. Build command: `npm run build`.
6. Build output directory: `dist`.
7. Deploy.

## Important limitations before using with a real business

This first version stores data in the browser on the device using localStorage. It is a working prototype, not a multi-user production system:
- Data is not shared between different devices or staff accounts.
- Clearing browser storage can remove the records.
- There is no login, cloud backup, payment integration, receipt printer or automated reminders.
- Do not enter real customer or pet information until authentication, access controls, backups and privacy requirements have been implemented and tested.

The starter records are fictional demo data. Replace them before demonstrating the app to a business.
