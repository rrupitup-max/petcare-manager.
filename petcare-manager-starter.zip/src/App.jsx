import React, { useEffect, useMemo, useState } from "react";
import {
  LayoutDashboard, Package, Scissors, ShoppingCart, Users, BarChart3,
  Search, Plus, Menu, X, PawPrint, AlertTriangle, CalendarDays, Trash2,
  Pencil, Check, Download, ArrowUpRight, Clock, Phone, Euro, Boxes,
  ChevronDown, Filter, Dog, Cat, CircleCheck, ClipboardList
} from "lucide-react";

const starterProducts = [
  { id: 1, name: "Premium Adult Dog Food", category: "Food", sku: "FO-001", price: 24.9, cost: 16, stock: 12, min: 5 },
  { id: 2, name: "Kitten Chicken Food", category: "Food", sku: "FO-002", price: 8.5, cost: 5.2, stock: 4, min: 6 },
  { id: 3, name: "Gentle Pet Shampoo", category: "Grooming", sku: "GR-001", price: 7.9, cost: 3.4, stock: 18, min: 5 },
  { id: 4, name: "Rubber Chew Toy", category: "Toys", sku: "TY-001", price: 5.5, cost: 2.1, stock: 3, min: 8 },
  { id: 5, name: "Adjustable Dog Harness", category: "Accessories", sku: "AC-001", price: 18, cost: 10, stock: 9, min: 3 },
  { id: 6, name: "Cat Litter 10L", category: "Hygiene", sku: "HY-001", price: 11.9, cost: 7.5, stock: 21, min: 5 }
];
const starterCustomers = [
  { id: 1, name: "Arta Hoxha", phone: "+355 68 111 2233", pet: "Luna · Golden Retriever", notes: "Sensitive skin" },
  { id: 2, name: "Erion Dervishi", phone: "+355 69 222 3344", pet: "Milo · British Shorthair", notes: "Prefers afternoon appointments" },
  { id: 3, name: "Sara Kola", phone: "+355 67 333 4455", pet: "Rocky · Beagle", notes: "Nervous around dryers" }
];
const today = new Date().toISOString().slice(0, 10);
const starterAppointments = [
  { id: 1, pet: "Luna", owner: "Arta Hoxha", service: "Full groom", date: today, time: "10:00", status: "Confirmed", price: 28 },
  { id: 2, pet: "Rocky", owner: "Sara Kola", service: "Bath & brush", date: today, time: "12:30", status: "In progress", price: 18 },
  { id: 3, pet: "Milo", owner: "Erion Dervishi", service: "Nail trim", date: today, time: "15:00", status: "Confirmed", price: 8 }
];
const starterSales = [
  { id: 1, name: "Premium Adult Dog Food", qty: 1, total: 24.9, date: today, method: "Cash" },
  { id: 2, name: "Gentle Pet Shampoo", qty: 2, total: 15.8, date: today, method: "Card" }
];

function read(key, fallback) {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; }
  catch { return fallback; }
}
function money(n) { return new Intl.NumberFormat("en-GB", { style: "currency", currency: "EUR" }).format(Number(n || 0)); }
function dateLabel(d) { return new Date(`${d}T12:00:00`).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }); }
function saveCsv(rows, filename) {
  const csv = rows.map(row => row.map(v => `"${String(v ?? "").replaceAll('"', '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob); const a = document.createElement("a");
  a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url);
}
function Modal({ title, onClose, children }) {
  return <div className="overlay" onMouseDown={e => e.target === e.currentTarget && onClose()}>
    <section className="modal"><div className="modal-head"><h2>{title}</h2><button className="icon-btn" onClick={onClose}><X size={19}/></button></div>{children}</section>
  </div>;
}
function Field({ label, children }) { return <label className="field"><span>{label}</span>{children}</label>; }

export default function App() {
  const [products, setProducts] = useState(() => read("pc_products", starterProducts));
  const [customers, setCustomers] = useState(() => read("pc_customers", starterCustomers));
  const [appointments, setAppointments] = useState(() => read("pc_appointments", starterAppointments));
  const [sales, setSales] = useState(() => read("pc_sales", starterSales));
  const [page, setPage] = useState("Dashboard");
  const [query, setQuery] = useState("");
  const [modal, setModal] = useState("");
  const [editing, setEditing] = useState(null);
  const [mobileNav, setMobileNav] = useState(false);
  const [toast, setToast] = useState("");

  useEffect(() => localStorage.setItem("pc_products", JSON.stringify(products)), [products]);
  useEffect(() => localStorage.setItem("pc_customers", JSON.stringify(customers)), [customers]);
  useEffect(() => localStorage.setItem("pc_appointments", JSON.stringify(appointments)), [appointments]);
  useEffect(() => localStorage.setItem("pc_sales", JSON.stringify(sales)), [sales]);

  const lowStock = products.filter(p => Number(p.stock) <= Number(p.min));
  const todaysAppointments = appointments.filter(a => a.date === today);
  const todaySales = sales.filter(s => s.date === today).reduce((sum, s) => sum + Number(s.total), 0);
  const groomingRevenue = appointments.filter(a => a.status === "Completed" && a.date.slice(0, 7) === today.slice(0, 7)).reduce((sum, a) => sum + Number(a.price), 0);
  const showToast = msg => { setToast(msg); setTimeout(() => setToast(""), 2600); };
  const nav = [
    ["Dashboard", LayoutDashboard], ["Inventory", Package], ["Grooming", Scissors],
    ["Sales", ShoppingCart], ["Customers", Users], ["Reports", BarChart3]
  ];
  const go = p => { setPage(p); setMobileNav(false); setQuery(""); };

  function saveProduct(e) {
    e.preventDefault(); const f = new FormData(e.currentTarget);
    const item = { id: editing?.id || Date.now(), name: f.get("name"), category: f.get("category"), sku: f.get("sku"), price: +f.get("price"), cost: +f.get("cost"), stock: +f.get("stock"), min: +f.get("min") };
    setProducts(old => editing ? old.map(p => p.id === editing.id ? item : p) : [item, ...old]);
    setModal(""); setEditing(null); showToast(editing ? "Product updated" : "Product added");
  }
  function saveCustomer(e) {
    e.preventDefault(); const f = new FormData(e.currentTarget);
    const item = { id: editing?.id || Date.now(), name: f.get("name"), phone: f.get("phone"), pet: f.get("pet"), notes: f.get("notes") };
    setCustomers(old => editing ? old.map(c => c.id === editing.id ? item : c) : [item, ...old]);
    setModal(""); setEditing(null); showToast("Customer saved");
  }
  function saveAppointment(e) {
    e.preventDefault(); const f = new FormData(e.currentTarget);
    const item = { id: editing?.id || Date.now(), pet: f.get("pet"), owner: f.get("owner"), service: f.get("service"), date: f.get("date"), time: f.get("time"), status: f.get("status"), price: +f.get("price") };
    setAppointments(old => editing ? old.map(a => a.id === editing.id ? item : a) : [item, ...old]);
    setModal(""); setEditing(null); showToast("Grooming appointment saved");
  }
  function addSale(e) {
    e.preventDefault(); const f = new FormData(e.currentTarget); const id = +f.get("productId");
    const product = products.find(p => p.id === id); const qty = +f.get("qty");
    if (!product || qty < 1 || qty > product.stock) { showToast("Check product and available stock"); return; }
    const total = qty * Number(product.price);
    setProducts(old => old.map(p => p.id === id ? { ...p, stock: Number(p.stock) - qty } : p));
    setSales(old => [{ id: Date.now(), name: product.name, qty, total, date: today, method: f.get("method") }, ...old]);
    setModal(""); showToast("Sale recorded and stock updated");
  }
  const openEdit = (kind, item) => { setEditing(item); setModal(kind); };
  const remove = (kind, id) => {
    if (!confirm("Delete this record?")) return;
    if (kind === "product") setProducts(v => v.filter(x => x.id !== id));
    if (kind === "customer") setCustomers(v => v.filter(x => x.id !== id));
    if (kind === "appointment") setAppointments(v => v.filter(x => x.id !== id));
    showToast("Record deleted");
  };

  const filteredProducts = products.filter(p => `${p.name} ${p.category} ${p.sku}`.toLowerCase().includes(query.toLowerCase()));
  const filteredCustomers = customers.filter(c => `${c.name} ${c.phone} ${c.pet}`.toLowerCase().includes(query.toLowerCase()));
  const filteredAppointments = appointments.filter(a => `${a.pet} ${a.owner} ${a.service} ${a.status}`.toLowerCase().includes(query.toLowerCase()));

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? "show" : ""}`}>
      <div className="brand"><div className="brand-icon"><PawPrint size={23}/></div><div><strong>PetCare</strong><small>SHOP MANAGER</small></div><button className="icon-btn mobile-close" onClick={() => setMobileNav(false)}><X/></button></div>
      <div className="workspace"><span className="workspace-dot"></span><div><b>My Pet Business</b><small>Workspace</small></div><ChevronDown size={15}/></div>
      <div className="nav-label">WORKSPACE</div>
      <nav>{nav.map(([name, Icon]) => <button key={name} className={`nav-item ${page === name ? "active" : ""}`} onClick={() => go(name)}><Icon size={18}/><span>{name}</span>{name === "Inventory" && lowStock.length > 0 && <i>{lowStock.length}</i>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="help-card"><PawPrint size={19}/><b>Made for pet people</b><p>Keep your shop and grooming appointments organised.</p></div><small>PetCare Manager · Demo v1.0</small></div>
    </aside>
    {mobileNav && <div className="scrim" onClick={() => setMobileNav(false)}></div>}
    <main className="main">
      <header className="topbar"><button className="icon-btn menu-btn" onClick={() => setMobileNav(true)}><Menu/></button><div className="breadcrumb">Workspace <span>/</span> <b>{page}</b></div><div className="top-right"><span className="today-label"><CalendarDays size={15}/> {dateLabel(today)}</span><div className="avatar">P</div></div></header>
      <div className="content">
        {page === "Dashboard" && <Dashboard products={products} lowStock={lowStock} appointments={todaysAppointments} todaySales={todaySales} customers={customers} groomingRevenue={groomingRevenue} go={go} setModal={setModal}/>}
        {page === "Inventory" && <><PageHead title="Inventory" sub="Manage products, stock levels and pricing." action="Add product" onAction={() => {setEditing(null);setModal("product")}}/><div className="stat-row compact"><Stat label="Total products" value={products.length} icon={Boxes}/><Stat label="Low stock alerts" value={lowStock.length} icon={AlertTriangle} warn/><Stat label="Inventory value" value={money(products.reduce((s,p)=>s + p.cost*p.stock,0))} icon={Euro}/></div><div className="panel"><Toolbar query={query} setQuery={setQuery} placeholder="Search products, category or SKU..."/><div className="table-wrap"><table><thead><tr><th>PRODUCT</th><th>SKU</th><th>CATEGORY</th><th>SELL PRICE</th><th>STOCK</th><th>STATUS</th><th></th></tr></thead><tbody>{filteredProducts.map(p=><tr key={p.id}><td><div className="product-cell"><div className="product-thumb"><Package size={17}/></div><b>{p.name}</b></div></td><td className="muted">{p.sku}</td><td>{p.category}</td><td>{money(p.price)}</td><td>{p.stock}</td><td><span className={`pill ${p.stock<=p.min?"pill-warn":"pill-green"}`}>{p.stock<=p.min?"Low stock":"In stock"}</span></td><td><RowActions onEdit={()=>openEdit("product",p)} onDelete={()=>remove("product",p.id)}/></td></tr>)}</tbody></table>{filteredProducts.length===0&&<Empty text="No products found."/>}</div></div></>}
        {page === "Grooming" && <><PageHead title="Grooming appointments" sub="Schedule and track grooming services." action="New appointment" onAction={() => {setEditing(null);setModal("appointment")}}/><div className="stat-row compact"><Stat label="Today's appointments" value={todaysAppointments.length} icon={CalendarDays}/><Stat label="In progress" value={appointments.filter(a=>a.status==="In progress").length} icon={Clock}/><Stat label="Completed this month" value={appointments.filter(a=>a.status==="Completed"&&a.date.slice(0,7)===today.slice(0,7)).length} icon={CircleCheck}/></div><div className="panel"><Toolbar query={query} setQuery={setQuery} placeholder="Search pet, owner or service..."/><div className="table-wrap"><table><thead><tr><th>PET / OWNER</th><th>SERVICE</th><th>DATE & TIME</th><th>PRICE</th><th>STATUS</th><th></th></tr></thead><tbody>{filteredAppointments.sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)).map(a=><tr key={a.id}><td><b>{a.pet}</b><small className="sub-cell">{a.owner}</small></td><td>{a.service}</td><td>{dateLabel(a.date)} · {a.time}</td><td>{money(a.price)}</td><td><select className="status-select" value={a.status} onChange={e=>setAppointments(old=>old.map(x=>x.id===a.id?{...x,status:e.target.value}:x))}><option>Confirmed</option><option>In progress</option><option>Completed</option><option>Cancelled</option></select></td><td><RowActions onEdit={()=>openEdit("appointment",a)} onDelete={()=>remove("appointment",a.id)}/></td></tr>)}</tbody></table>{filteredAppointments.length===0&&<Empty text="No appointments found."/>}</div></div></>}
        {page === "Sales" && <><PageHead title="Sales" sub="Record shop sales and see your recent transactions." action="Record a sale" onAction={() => setModal("sale")}/><div className="stat-row compact"><Stat label="Today's sales" value={money(todaySales)} icon={Euro}/><Stat label="Transactions today" value={sales.filter(s=>s.date===today).length} icon={ShoppingCart}/><Stat label="All-time sales" value={money(sales.reduce((s,x)=>s+x.total,0))} icon={BarChart3}/></div><div className="panel"><div className="panel-title"><div><h3>Recent transactions</h3><p>Product sales recorded in this workspace</p></div><button className="btn btn-light btn-sm" onClick={()=>saveCsv([["Date","Product","Quantity","Total","Payment"],...sales.map(s=>[s.date,s.name,s.qty,s.total,s.method])],"petcare-sales.csv")}><Download size={15}/> Export CSV</button></div><div className="table-wrap"><table><thead><tr><th>DATE</th><th>PRODUCT</th><th>QTY</th><th>PAYMENT</th><th>TOTAL</th></tr></thead><tbody>{sales.map(s=><tr key={s.id}><td>{dateLabel(s.date)}</td><td><b>{s.name}</b></td><td>{s.qty}</td><td>{s.method}</td><td><b>{money(s.total)}</b></td></tr>)}</tbody></table>{sales.length===0&&<Empty text="No sales recorded yet."/>}</div></div></>}
        {page === "Customers" && <><PageHead title="Customers & pets" sub="Keep owner contact details and pet preferences in one place." action="Add customer" onAction={() => {setEditing(null);setModal("customer")}}/><div className="panel"><Toolbar query={query} setQuery={setQuery} placeholder="Search customers, phone or pet..."/><div className="customer-grid">{filteredCustomers.map(c=><div className="customer-card" key={c.id}><div className="customer-top"><div className="customer-avatar"><PawPrint/></div><RowActions onEdit={()=>openEdit("customer",c)} onDelete={()=>remove("customer",c.id)}/></div><h3>{c.name}</h3><p className="contact"><Phone size={13}/>{c.phone}</p><div className="pet-tag"><Dog size={15}/>{c.pet}</div>{c.notes&&<p className="notes">{c.notes}</p>}</div>)}</div>{filteredCustomers.length===0&&<Empty text="No customers found."/>}</div></>}
        {page === "Reports" && <><PageHead title="Reports" sub="A simple overview of sales, products and grooming activity."/><div className="stat-row"><Stat label="Product sales" value={money(sales.reduce((s,x)=>s+x.total,0))} icon={ShoppingCart}/><Stat label="Grooming completed" value={appointments.filter(a=>a.status==="Completed").length} icon={Scissors}/><Stat label="Estimated stock cost" value={money(products.reduce((s,p)=>s+p.cost*p.stock,0))} icon={Package}/></div><div className="report-grid"><div className="panel report-panel"><h3>Sales by product</h3><p className="muted">Based on recorded transactions</p>{Object.entries(sales.reduce((acc,s)=>{acc[s.name]=(acc[s.name]||0)+s.total;return acc;},{})).sort((a,b)=>b[1]-a[1]).map(([name,total])=><div className="bar-row" key={name}><div><span>{name}</span><b>{money(total)}</b></div><div className="bar-bg"><i style={{width:`${Math.max(4,total/Math.max(1,...Object.values(sales.reduce((acc,s)=>{acc[s.name]=(acc[s.name]||0)+s.total;return acc;},{})))*100)}%`}}/></div></div>)}{sales.length===0&&<Empty text="Record sales to see a report."/>}</div><div className="panel report-panel"><h3>Grooming summary</h3><p className="muted">Appointment status overview</p>{["Confirmed","In progress","Completed","Cancelled"].map(status=><div className="summary-line" key={status}><span>{status}</span><b>{appointments.filter(a=>a.status===status).length}</b></div>)}<button className="btn btn-light export-wide" onClick={()=>saveCsv([["Date","Pet","Owner","Service","Status","Price"],...appointments.map(a=>[a.date,a.pet,a.owner,a.service,a.status,a.price])],"petcare-grooming.csv")}><Download size={15}/> Export grooming report</button></div></div></>}
      </div>
    </main>
    {modal==="product"&&<Modal title={editing?"Edit product":"Add product"} onClose={()=>{setModal("");setEditing(null)}}><form onSubmit={saveProduct} className="form-grid"><Field label="Product name"><input name="name" required defaultValue={editing?.name}/></Field><Field label="SKU / code"><input name="sku" required defaultValue={editing?.sku}/></Field><Field label="Category"><select name="category" defaultValue={editing?.category||"Food"}><option>Food</option><option>Toys</option><option>Accessories</option><option>Grooming</option><option>Hygiene</option><option>Other</option></select></Field><Field label="Selling price (€)"><input name="price" type="number" min="0" step="0.01" required defaultValue={editing?.price}/></Field><Field label="Cost price (€)"><input name="cost" type="number" min="0" step="0.01" required defaultValue={editing?.cost}/></Field><Field label="Current stock"><input name="stock" type="number" min="0" required defaultValue={editing?.stock}/></Field><Field label="Low-stock threshold"><input name="min" type="number" min="0" required defaultValue={editing?.min??5}/></Field><div className="form-actions"><button type="button" className="btn btn-light" onClick={()=>setModal("")}>Cancel</button><button className="btn btn-primary"><Check size={16}/> Save product</button></div></form></Modal>}
    {modal==="customer"&&<Modal title={editing?"Edit customer":"Add customer"} onClose={()=>{setModal("");setEditing(null)}}><form onSubmit={saveCustomer} className="form-grid"><Field label="Owner name"><input name="name" required defaultValue={editing?.name}/></Field><Field label="Phone number"><input name="phone" required defaultValue={editing?.phone}/></Field><Field label="Pet name and breed"><input name="pet" required defaultValue={editing?.pet} placeholder="e.g. Bella · Cocker Spaniel"/></Field><Field label="Notes / preferences"><textarea name="notes" rows="3" defaultValue={editing?.notes}/></Field><div className="form-actions"><button type="button" className="btn btn-light" onClick={()=>setModal("")}>Cancel</button><button className="btn btn-primary"><Check size={16}/> Save customer</button></div></form></Modal>}
    {modal==="appointment"&&<Modal title={editing?"Edit appointment":"New grooming appointment"} onClose={()=>{setModal("");setEditing(null)}}><form onSubmit={saveAppointment} className="form-grid"><Field label="Pet name"><input name="pet" required defaultValue={editing?.pet}/></Field><Field label="Owner name"><input name="owner" required defaultValue={editing?.owner}/></Field><Field label="Service"><select name="service" defaultValue={editing?.service||"Full groom"}><option>Full groom</option><option>Bath & brush</option><option>Nail trim</option><option>Haircut</option><option>De-shedding</option><option>Other</option></select></Field><Field label="Price (€)"><input name="price" type="number" min="0" step="0.01" required defaultValue={editing?.price??20}/></Field><Field label="Date"><input name="date" type="date" required defaultValue={editing?.date||today}/></Field><Field label="Time"><input name="time" type="time" required defaultValue={editing?.time||"10:00"}/></Field><Field label="Status"><select name="status" defaultValue={editing?.status||"Confirmed"}><option>Confirmed</option><option>In progress</option><option>Completed</option><option>Cancelled</option></select></Field><div className="form-actions"><button type="button" className="btn btn-light" onClick={()=>setModal("")}>Cancel</button><button className="btn btn-primary"><Check size={16}/> Save appointment</button></div></form></Modal>}
    {modal==="sale"&&<Modal title="Record a sale" onClose={()=>setModal("")}><form onSubmit={addSale} className="form-grid"><Field label="Product"><select name="productId" required>{products.filter(p=>p.stock>0).map(p=><option value={p.id} key={p.id}>{p.name} · {money(p.price)} · {p.stock} in stock</option>)}</select></Field><Field label="Quantity"><input name="qty" type="number" min="1" defaultValue="1" required/></Field><Field label="Payment method"><select name="method"><option>Cash</option><option>Card</option><option>Bank transfer</option><option>Other</option></select></Field><div className="form-actions"><button type="button" className="btn btn-light" onClick={()=>setModal("")}>Cancel</button><button className="btn btn-primary"><Check size={16}/> Record sale</button></div></form></Modal>}
    {toast&&<div className="toast"><CircleCheck size={17}/>{toast}</div>}
  </div>;
}

function PageHead({title,sub,action,onAction}) { return <div className="page-head"><div><div className="eyebrow">PETCARE WORKSPACE</div><h1>{title}</h1><p>{sub}</p></div>{action&&<button className="btn btn-primary" onClick={onAction}><Plus size={17}/>{action}</button>}</div>; }
function Stat({label,value,icon:Icon,warn}) { return <div className="stat-card"><div className={`stat-icon ${warn?"warn":""}`}><Icon size={19}/></div><div><p>{label}</p><strong>{value}</strong></div></div>; }
function Toolbar({query,setQuery,placeholder}) { return <div className="toolbar"><div className="searchbox"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={placeholder}/></div><span className="muted small"><Filter size={14}/> Search records</span></div>; }
function RowActions({onEdit,onDelete}) { return <div className="row-actions"><button title="Edit" onClick={onEdit}><Pencil size={15}/></button><button title="Delete" onClick={onDelete}><Trash2 size={15}/></button></div>; }
function Empty({text}) { return <div className="empty"><PawPrint size={24}/><p>{text}</p></div>; }
function Dashboard({products,lowStock,appointments,todaySales,customers,groomingRevenue,go,setModal}) {
  const upcoming = [...appointments].sort((a,b)=>a.time.localeCompare(b.time)).slice(0,4);
  return <>
    <div className="welcome"><div><div className="eyebrow light-eyebrow">TUESDAY · YOUR BUSINESS AT A GLANCE</div><h1>Good morning <span>👋</span></h1><p>Here's what's happening at your pet shop today.</p></div><div className="welcome-paw"><PawPrint size={94}/></div></div>
    <div className="stat-row"><Stat label="Today's product sales" value={money(todaySales)} icon={Euro}/><Stat label="Grooming appointments" value={appointments.length} icon={Scissors}/><Stat label="Products in catalogue" value={products.length} icon={Package}/><Stat label="Registered customers" value={customers.length} icon={Users}/></div>
    <div className="dashboard-grid"><div className="panel"><div className="panel-title"><div><h3>Today's grooming</h3><p>Your scheduled appointments</p></div><button className="text-btn" onClick={()=>go("Grooming")}>View all <ArrowUpRight size={15}/></button></div>{upcoming.length?upcoming.map(a=><div className="appointment-row" key={a.id}><div className="time-block">{a.time}</div><div className="appointment-pet"><div className="pet-circle"><PawPrint size={17}/></div><div><b>{a.pet}</b><small>{a.owner} · {a.service}</small></div></div><span className={`pill ${a.status==="Completed"?"pill-green":a.status==="In progress"?"pill-blue":"pill-yellow"}`}>{a.status}</span></div>):<Empty text="No appointments scheduled for today."/>}<button className="btn btn-light add-inline" onClick={()=>setModal("appointment")}><Plus size={16}/> Add appointment</button></div>
      <div className="panel"><div className="panel-title"><div><h3>Stock alerts</h3><p>Products that need attention</p></div><button className="text-btn" onClick={()=>go("Inventory")}>Inventory <ArrowUpRight size={15}/></button></div>{lowStock.length?lowStock.slice(0,5).map(p=><div className="stock-row" key={p.id}><div className="stock-product"><div className="product-thumb"><Package size={16}/></div><div><b>{p.name}</b><small>{p.category}</small></div></div><span className="stock-count">{p.stock} left</span></div>):<div className="good-stock"><CircleCheck size={20}/> All products are sufficiently stocked.</div>}</div>
    </div>
    <div className="quick-actions"><div><h3>Quick actions</h3><p>Common tasks, one click away.</p></div><button onClick={()=>setModal("sale")}><ShoppingCart size={18}/><span><b>Record a sale</b><small>Sell a shop product</small></span><ArrowUpRight size={16}/></button><button onClick={()=>setModal("customer")}><Users size={18}/><span><b>Add customer</b><small>Register an owner and pet</small></span><ArrowUpRight size={16}/></button><button onClick={()=>setModal("appointment")}><Scissors size={18}/><span><b>Book grooming</b><small>Create an appointment</small></span><ArrowUpRight size={16}/></button></div>
  </>;
}
